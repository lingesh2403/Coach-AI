// File: src/pages/Home.jsx

import React from "react";
import Navbar from "../components/Navbar";
import "../styles/Home.css";

const Home = () => {
    return (
        <div className="container">
            <header>
                <Navbar />
            </header>

            <div className="scrollable">
                <div className="hero">
                    <h1>Welcome to Coach Ai</h1>
                </div>

                <div className="content">
                    <h2>About Us</h2>
                    <div className="vision">
                        <h3>Our Vision</h3>
                        <p>At Coach AI, we envision a world where technology empowers individuals to achieve holistic wellness and live healthier, happier lives.</p>
                    </div>
                    <div className="mission">
                        <h3>Our Mission</h3>
                        <p>Our mission is to provide personalized and interactive wellness solutions through cutting-edge AI, ensuring users can meet their mental and physical health goals effectively.</p>
                    </div>
                    <div className="future">
                        <h3>Future Plans</h3>
                        <p>We aim to continually innovate by introducing advanced AI capabilities, expanding our resources, and building a global community focused on wellness and self-improvement.</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Home;
