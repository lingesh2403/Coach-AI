// import React from 'react';
// import Navbar from '../components/Navbar';
// import ChatInterface from '../Components/ChatInterface';
// import '../styles/ChatbotPage.css';

// const ChatbotPage = () => {
//   return (
//     <div className="chatbot-page">
//       <Navbar />
//       <ChatInterface />
//     </div>
//   );
// };

// export default ChatbotPage;

import React from 'react';
import Navbar from '../components/Navbar';
import ChatInterface from '../Components/ChatInterface';
import '../styles/ChatbotPage.css';

const ChatbotPage = () => {
  return (
    <div className="chatbot-page">
      <Navbar />
      <div className="chat-interface-wrapper">
        <ChatInterface />
      </div>
    </div>
  );
};

export default ChatbotPage;
