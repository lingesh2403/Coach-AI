import React from "react";
import Navbar from "../components/Navbar";
import GoalsContent from "../Components/Goals/GoalsContent";

const GoalsPage = () => {
  return (
    <div className="container">
      <Navbar />
      <GoalsContent />
    </div>
  );
};

export default GoalsPage;
