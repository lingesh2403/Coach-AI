import React from "react";
import ProfilePicture from "../Components/Profile/ProfilePicture";
import BasicInfo from "../Components/Profile/BasicInfo";
import HealthDetails from "../Components/Profile/HealthDetails";
import AccountSettings from "../Components/Profile/AccountSettings";
import EditProfileForm from "../Components/Profile/EditProfileForm";
import "../styles/ProfilePage.css";

const ProfilePage = () => {
  return (
    <div className="container">
      <header className="header">
        <div className="navbar">
          <h1>Coach AI</h1>
          <ul>
            <li><a href="/">Coach AI</a></li>
            {/* <li><a href="/progress">My Progress</a></li> */}
            <li><a href="/goals">Goals</a></li>
            <li><a href="/me">Me</a></li>
          </ul>
        </div>
      </header>

      <div className="profile">
        <ProfilePicture />
        <BasicInfo />
        <HealthDetails />
        <AccountSettings />
        <EditProfileForm />
      </div>
    </div>
  );
};

export default ProfilePage;
