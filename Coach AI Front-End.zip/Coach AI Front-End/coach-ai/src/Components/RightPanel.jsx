// import React from "react";
// import ChatBox from "./ChatBot";
// import ChatInput from "./ChatInput";
// import "../styles/RightPanel.css";

// const RightPanel = () => {
//   return (
//     <div className="right-panel">
//       <ChatBox />
//       <ChatInput />
//     </div>
//   );
// };

// export default RightPanel;

import React from "react";
import ChatBot from "./ChatBot";
import ChatInput from "./ChatInput";
import "../styles/RightPanel.css";

const RightPanel = () => {
  return (
    <div className="right-panel">
      <ChatBot />
      <ChatInput />
    </div>
  );
};

export default RightPanel;
