import React from "react";
import "../../styles/ProfilePicture.css";
import profileImage from "../../images/profile.avif"; 

const ProfilePicture = () => {
  return (
    <div className="profile-picture">
      <img src={profileImage} alt="Profile" />
    </div>
  );
};

export default ProfilePicture;
