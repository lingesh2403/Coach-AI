import React from "react";
import "../../styles/BasicInfo.css";

const BasicInfo = () => {
  return (
    <div className="section basic-info">
      <h2>Basic Information</h2>
      <p><strong>Name:</strong> John Doe</p>
      <p><strong>Age:</strong> 30</p>
      <p><strong>Gender:</strong> Male</p>
      <p><strong>Contact:</strong> john.doe@example.com</p>
    </div>
  );
};

export default BasicInfo;
