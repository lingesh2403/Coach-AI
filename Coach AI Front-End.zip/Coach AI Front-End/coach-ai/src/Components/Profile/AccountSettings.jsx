import React from "react";
import "../../styles/AccountSettings.css";


const AccountSettings = () => {
  return (
    <div className="section account-settings">
      <h2>Account Settings</h2>
      <p><strong>Password:</strong> *********</p>
      <p><strong>Notifications:</strong> Enabled</p>
      <p><strong>Privacy:</strong> Public</p>
    </div>
  );
};

export default AccountSettings;
