import React from "react";
import "../../styles/HealthDetails.css";

const HealthDetails = () => {
  return (
    <div className="section health-info">
      <h2>Health Details</h2>
      <p><strong>Weight:</strong> 70 kg</p>
      <p><strong>Height:</strong> 175 cm</p>
      <p><strong>BMI:</strong> 22.9</p>
      <p><strong>Allergies:</strong> None</p>
      <p><strong>Medical Conditions:</strong> None</p>
    </div>
  );
};

export default HealthDetails;
