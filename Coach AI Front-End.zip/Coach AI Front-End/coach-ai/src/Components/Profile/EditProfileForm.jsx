import React from "react";
import "../../styles/EditProfileForm.css";

const EditProfileForm = () => {
  return (
    <div className="section edit-form">
      <h2>Edit Profile</h2>
      <form>
        <input type="text" placeholder="Name" />
        <input type="number" placeholder="Age" />
        <select>
          <option>Male</option>
          <option>Female</option>
          <option>Other</option>
        </select>
        <input type="email" placeholder="Contact" />
        <input type="number" placeholder="Weight (kg)" />
        <input type="number" placeholder="Height (cm)" />
        <textarea placeholder="Allergies or Medical Conditions"></textarea>
        <button type="submit">Save Changes</button>
      </form>
    </div>
  );
};

export default EditProfileForm;
