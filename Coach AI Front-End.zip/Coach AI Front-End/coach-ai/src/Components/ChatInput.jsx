// import React from "react";
// import "../styles/ChatInput.css";

// const ChatInput = () => {
//   return (
//     <div className="chat-input">
//       <input type="text" placeholder="Type your message here..." />
//       <button>Send</button>
//     </div>
//   );
// };

// export default ChatInput;

import React from "react";
import "../styles/ChatInput.css";

const ChatInput = () => {
  return (
    <div className="chat-input">
      <input type="text" placeholder="Type your message here..." />
      <button>Send</button>
    </div>
  );
};

export default ChatInput;
