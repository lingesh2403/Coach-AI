// import React from "react";
// import "../styles/LeftPanel.css";

// const LeftPanel = () => {
//   return (
//     <div className="left-panel">
//       <h2>Your Coach Insights</h2>
//       <div className="insights">
//         <h3>Recent Activities</h3>
//         <p>Workout: 30 mins Yoga</p>
//         <p>Steps: 7500</p>
//         <p>Diet: Maintained calorie intake</p>
//       </div>
//       <div className="information">
//         <h3>Tips</h3>
//         <p>"Hydrate well after workouts for better recovery."</p>
//         <p>"Maintain a balanced diet to achieve consistent results."</p>
//       </div>
//     </div>
//   );
// };

// export default LeftPanel;

import React from "react";
import "../styles/LeftPanel.css";

const LeftPanel = () => {
  return (
    <div className="left-panel">
      <h2>Your Coach Insights</h2>
      <div className="insights">
        <h3>Recent Activities</h3>
        <p>Workout: 30 mins Yoga</p>
        <p>Steps: 7500</p>
        <p>Diet: Maintained calorie intake</p>
      </div>
      <div className="information">
        <h3>Tips</h3>
        <p>"Hydrate well after workouts for better recovery."</p>
        <p>"Maintain a balanced diet to achieve consistent results."</p>
      </div>
    </div>
  );
};

export default LeftPanel;
