import React from "react";
import ProgressBar from "./ProgressBar";
import "../../styles/GoalItem.css";

const GoalItem = ({ label, progress }) => {
  return (
    <div className="goal-item">
      <p>{label}</p>
      <ProgressBar progress={progress} />
    </div>
  );
};

export default GoalItem;
