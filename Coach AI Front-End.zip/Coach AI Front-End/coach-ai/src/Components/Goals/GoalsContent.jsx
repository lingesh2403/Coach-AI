import React from "react";
import GoalItem from "./GoalItem";
import AddGoalButton from "./AddGoalButton";
import "../../styles/GoalsContent.css";

const GoalsContent = () => {
  return (
    <div className="goals-content">
      <div className="section">
        <h2>Daily Goals</h2>
        <GoalItem label="Workout Duration: 30 mins" progress={70} />
        <GoalItem label="Steps Count: 10,000" progress={50} />
        <GoalItem label="Calorie Intake: 2000 kcal" progress={90} />
      </div>

      <div className="section">
        <h2>Weekly Goals</h2>
        <GoalItem label="Workouts: 5 days" progress={40} />
        <GoalItem label="Calories to Burn: 3500 kcal" progress={60} />
        <GoalItem label="Swimming Sessions: 2 times" progress={30} />
      </div>

      <div className="section">
        <h2>Diet Goals</h2>
        <GoalItem label="Carbs: 50%" progress={50} />
        <GoalItem label="Protein: 30%" progress={30} />
        <GoalItem label="Fat: 20%" progress={20} />
      </div>

      <div className="section motivational">
        <h2>Motivational Tips</h2>
        <p>"The journey of a thousand miles begins with a single step."</p>
        <p>"Consistency is key to achieving your goals."</p>
      </div>

      <AddGoalButton />
    </div>
  );
};

export default GoalsContent;
