import React from "react";
import "../../styles/AddGoalButton.css";

const AddGoalButton = () => {
  return (
    <div className="add-goal">
      <button>Add New Goal</button>
    </div>
  );
};

export default AddGoalButton;
