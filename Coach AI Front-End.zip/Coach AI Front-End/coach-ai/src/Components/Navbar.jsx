// // src/components/Navbar.jsx
// import React from 'react';
// import '../styles/Navbar.css';

// const Navbar = () => {
//     return (
//         <nav className="navbar">
//             <h1>Coach AI</h1>
//             <ul>
//                 <li><a href="#">Coach AI</a></li>
//                 <li><a href="#">My Progress</a></li>
//                 <li><a href="#">Goals</a></li>
//                 <li><a href="#">Me</a></li>
//             </ul>
//         </nav>
//     );
// };

// export default Navbar;
import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Navbar.css';

const Navbar = () => {
  return (
    <header className="navbar">
      <div className="navbar-container">
        <h1>Coach Ai</h1>
        <ul className="navbar-links">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/chatbot">Coach </Link></li>
          {/* <li><Link to="/my-progress">My Progress</Link></li> */}
          <li><Link to="/goals">Goals</Link></li>
          <li><Link to="/me">Me</Link></li>
        </ul>
      </div>
    </header>
  );
};

export default Navbar;
