// import React from "react";
// import "../styles/ChatBox.css";

// const ChatBot = () => {
//   return (
//     <div className="chat-box">
//       <p><strong>Coach AI:</strong> Hello! How can I assist you today?</p>
//     </div>
//   );
// };

// export default ChatBot;

import React from "react";
import "../styles/ChatBox.css";

const ChatBot = () => {
  return (
    <div className="chat-box">
      <p><strong>Coach AI:</strong> Hello! How can I assist you today?</p>
    </div>
  );
};

export default ChatBot;
