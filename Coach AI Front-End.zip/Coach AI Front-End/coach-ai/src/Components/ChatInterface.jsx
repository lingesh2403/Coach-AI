// import React from "react";
// import LeftPanel from "./LeftPanel";
// import RightPanel from "./RightPanel";
// import "../styles/ChatInterface.css";

// const ChatInterface = () => {
//   return (
//     <div className="chat-interface">
//       <LeftPanel />
//       <RightPanel />
//     </div>
//   );
// };

// export default ChatInterface;

// import React from "react";
// import LeftPanel from "./LeftPanel";
// import RightPanel from "./RightPanel";
// import "../styles/ChatInterface.css";

// const ChatInterface = () => {
//   return (
//     <div className="chat-interface">
//       <LeftPanel />
//       <RightPanel />
//     </div>
//   );
// };

// export default ChatInterface;

import React from "react";
import LeftPanel from "./LeftPanel";
import RightPanel from "./RightPanel";
import "../styles/ChatInterface.css";

const ChatInterface = () => {
  return (
    <div className="chat-container">
      <div className="chat-box-wrapper">
        <LeftPanel />
        <RightPanel />
      </div>
    </div>
  );
};

export default ChatInterface;
